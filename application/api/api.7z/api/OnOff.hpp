#pragma once

#include "common/Types.hpp"



namespace application::api::onoff {



const std::string s_interface_name = "OnOff";



} // namespace application::api::onoff
